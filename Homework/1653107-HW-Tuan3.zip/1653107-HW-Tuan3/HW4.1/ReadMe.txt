﻿- Họ và tên: Nguyễn Trọng An 
- MSSV: 1653107 
- Lớp: 16CLC2

- Các yêu cầu đã hoàn thành:
+ Xây dựng dialog nhập thông tin sinh viên
+ Khởi tạo dialog set các giá trị mặc định
+ Enable button OK khi có thông tin được nhập, ko có thông tin nhập thì disable
+ Click OK lấy thông tin trên dialog lưu vào file info.txt

- Các yêu cầu chưa hoàn thành: Không có
- Version Visual Studio build chương trình: Visual Studio 15
- Các lưu ý khác khi build và chạy chương trình: không có
